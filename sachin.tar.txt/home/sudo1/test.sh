#!/bin/ksh
fun()
echo'this is test'
# terminate our shell if success
exit!
fun()
$grep "exit" test.txt
exit!

